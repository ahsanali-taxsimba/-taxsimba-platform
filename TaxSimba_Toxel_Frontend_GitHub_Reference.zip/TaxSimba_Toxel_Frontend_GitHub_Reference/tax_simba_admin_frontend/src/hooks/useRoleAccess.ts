// src/hooks/useRoleAccess.ts
import { useSession } from "next-auth/react";
import { authConfig } from "@/lib/auth-config";

export function useRoleAccess() {
  const { data: session } = useSession();
  
  const userRole = session?.user?.role;
  
  // Helper function to check if user can access a route
  const canAccessRoute = (route: string) => {
    if (!userRole) return false;
    
    // ADMIN can access everything
    if (userRole === "ADMIN") return true;
    
    // Check if route is restricted for ACCOUNTANT
    if (userRole === "ACCOUNTANT") {
      return !authConfig.restrictedForAccountant.some(restrictedRoute => 
        route.startsWith(restrictedRoute)
      );
    }
    
    return false;
  };
  
  return {
    canAccessManageAccountant: canAccessRoute("/manage-accountant"),
    canAccessManageClient: canAccessRoute("/manage-client"),
    canAccessDashboard: canAccessRoute("/dashboard"),
    isAdmin: userRole === "ADMIN",
    isAccountant: userRole === "ACCOUNTANT",
    userRole,
    canAccessRoute, // Expose the function for custom route checks
  };
}