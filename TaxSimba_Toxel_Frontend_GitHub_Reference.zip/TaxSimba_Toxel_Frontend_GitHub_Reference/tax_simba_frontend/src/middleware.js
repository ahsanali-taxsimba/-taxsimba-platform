// Force Node.js runtime — next-auth/jwt uses jose which needs code generation
// (eval/new Function), which is blocked in the default Edge Runtime.
export const runtime = 'nodejs';

import { getToken } from 'next-auth/jwt';
import { NextResponse } from 'next/server';

async function getAuthToken(req) {
  // Try with the frontend session cookie name, using NEXTAUTH_SECRET (consistent with route.js)
  const defaultToken = await getToken({
    req,
    secret: process.env.NEXTAUTH_SECRET,
    cookieName: 'next-auth.session-token-frontend',
  });
  if (defaultToken) return defaultToken;

  // In production NextAuth may prefix secure cookies with "__Secure-"
  const token = await getToken({
    req,
    secret: process.env.NEXTAUTH_SECRET,
    cookieName: '__Secure-next-auth.session-token-frontend',
  });
  if (token) return token;

  return null;
}

export async function middleware(req) {
  const token = await getAuthToken(req);
  const { pathname } = req.nextUrl;

  if (pathname === '/index.html') {
    return NextResponse.redirect(new URL('/', req.url), 301);
  }


  // Allow access to public assets and API
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/frontend-api') ||

    pathname === '/favicon.ico'
  ) {
    return NextResponse.next();
  }

  // If NOT authenticated
  if (!token) {
    // Allow access to login and register
    if (pathname === '/login'
      || pathname === '/register'
      || pathname === '/forgot-password'
      || pathname === '/reset-password'
      || pathname === '/verify-email'
    ) {
      return NextResponse.next();
    }

    // Block dashboard, tax-return-form, planlist, mtd-dashboard and redirect to login
    if (pathname.startsWith('/dashboard')
      || pathname.startsWith('/tax-return-form')
      || pathname.startsWith('/my-tax-return')
      || pathname.startsWith('/mtd-dashboard')
      || pathname === '/planlist'
    ) {
      return NextResponse.redirect(new URL('/login', req.url));
    }
  }

  // If authenticated
  if (token) {
    const hasSubscription = token?.isSubscriptionBuy || token?.user?.isSubscriptionBuy || token?.subscription?.status === 'active';
    const hasSignedLetter = token?.user?.isEngagementLetterAccepted === true;
    const userRole = token?.user?.userRole || token?.user?.role;
    const hasSubmittedTaxInfo = token?.user?.isTaxInfoSubmitted === true;

    // Prevent login/register for authenticated users
    if (pathname === '/login'
      || pathname === '/register'
      || pathname === '/forgot-password'
      || pathname === '/reset-password'
      || pathname === '/verify-email'
    ) {
      if (hasSubscription === false) {
        return NextResponse.redirect(new URL('/planlist', req.url));
      }
      if (!hasSignedLetter) {
        return NextResponse.redirect(new URL('/engagement-letter', req.url));
      }
      if (userRole === 'MTD' && !hasSubmittedTaxInfo) {
        return NextResponse.redirect(new URL('/engagement-letter', req.url));
      }
      if (userRole === 'MTD') {
        return NextResponse.redirect(new URL('/mtd-dashboard', req.url));
      }
      return NextResponse.redirect(new URL('/dashboard', req.url));
    }

    // Force users without a subscription to the planlist page if they try to access restricted routes
    if (!hasSubscription) {
      if (pathname.startsWith('/dashboard')
        || pathname.startsWith('/tax-return-form')
        || pathname.startsWith('/my-tax-return')
        || pathname.startsWith('/mtd-dashboard')
        || pathname === '/engagement-letter'
      ) {
        return NextResponse.redirect(new URL('/planlist', req.url));
      }
    }

    // After purchasing a plan, force engagement letter signing before dashboard access
    if (hasSubscription && !hasSignedLetter) {
      if (pathname.startsWith('/dashboard')
        || pathname.startsWith('/tax-return-form')
        || pathname.startsWith('/my-tax-return')
        || pathname.startsWith('/mtd-dashboard')
      ) {
        return NextResponse.redirect(new URL('/engagement-letter', req.url));
      }
    }

    // Force MTD users to submit tax info before getting to dashboard
    if (hasSubscription && hasSignedLetter && userRole === 'MTD' && !hasSubmittedTaxInfo) {
      if (pathname.startsWith('/dashboard')
        || pathname.startsWith('/tax-return-form')
        || pathname.startsWith('/my-tax-return')
        || pathname.startsWith('/mtd-dashboard')
        || pathname !== '/engagement-letter'
      ) {
        if (pathname !== '/engagement-letter') {
          return NextResponse.redirect(new URL('/engagement-letter', req.url));
        }
      }
    }

    // Restrict MTD users to MTD dashboard and block normal dashboard
    if (hasSubscription && hasSignedLetter && userRole === 'MTD' && hasSubmittedTaxInfo) {
      if (pathname.startsWith('/dashboard')
        || pathname.startsWith('/tax-return-form')
        || pathname.startsWith('/my-tax-return')
      ) {
        return NextResponse.redirect(new URL('/mtd-dashboard', req.url));
      }
    }

    // Restrict normal users to normal dashboard and block MTD dashboard
    if (hasSubscription && hasSignedLetter && userRole !== 'MTD') {
      if (pathname.startsWith('/mtd-dashboard')) {
        return NextResponse.redirect(new URL('/dashboard', req.url));
      }
    }

    // Allow authenticated users to visit /planlist (they may not have a plan yet)
    if (pathname === '/planlist') {
      return NextResponse.next();
    }

    // Allow access to other pages
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/login',
    '/register',
    '/index.html',
    '/planlist',
    '/engagement-letter',
    '/dashboard',
    '/dashboard/:path*',
    '/mtd-dashboard',
    '/mtd-dashboard/:path*',
    '/forgot-password',
    '/reset-password',
    '/verify-email',
    '/tax-return-form/:path*',
    '/my-tax-return/:path*',
  ],
};
