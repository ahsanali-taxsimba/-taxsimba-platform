"use client";
import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Spinner, Card, Button, Form } from 'react-bootstrap';
import { MdCheckCircle, MdDelete } from "react-icons/md";
import axios from 'axios';
import { useRouter, useParams } from 'next/navigation';
import { useSession } from 'next-auth/react';
import toast from 'react-hot-toast';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements, PaymentRequestButtonElement, PaymentMethodMessagingElement } from '@stripe/react-stripe-js';
import { FaTrash, FaCcVisa, FaCcMastercard, FaCcAmex, FaCcDiscover, FaCcJcb, FaCreditCard, FaApple, FaGoogle } from 'react-icons/fa';
import { getCurrencySymbol } from '@/utils/commonHelper';

const getCardIcon = (brand) => {
    switch (brand?.toLowerCase()) {
        case 'visa': return <FaCcVisa size={30} className="text-primary" />;
        case 'mastercard': return <FaCcMastercard size={30} className="text-danger" />;
        case 'amex': return <FaCcAmex size={30} className="text-info" />;
        case 'discover': return <FaCcDiscover size={30} className="text-warning" />;
        case 'jcb': return <FaCcJcb size={30} className="text-success" />;
        default: return <FaCreditCard size={30} className="text-muted" />;
    }
};

// Initialize Stripe
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);



// ─────────────────────────────────────────────────────────────────────────────
// Add Card Form Component (existing)
// ─────────────────────────────────────────────────────────────────────────────
const AddCardForm = ({ onCardAdded }) => {
    const stripe = useStripe();
    const elements = useElements();
    const [loading, setLoading] = useState(false);
    const { data: session } = useSession();

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!stripe || !elements) return;

        setLoading(true);
        try {
            const cardElement = elements.getElement(CardElement);

            // Create a token using Stripe
            const { error, token } = await stripe.createToken(cardElement);

            if (error) {
                toast.error(error.message);
                setLoading(false);
                return;
            }

            // Send card token info to our backend
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
            await axios.post(
                `${apiUrl}client/subscription/add-card`,
                { cardTokenId: token.id },
                { headers: { Authorization: `Bearer ${session?.accessToken}` } }
            );

            toast.success("Card added successfully");
            cardElement.clear();
            if (onCardAdded) onCardAdded();
        } catch (err) {
            console.error(err);
            toast.error(err?.response?.data?.message || "Failed to add card");
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="add-card-form p-3 border rounded mb-4 bg-white">
            <h6 className="mb-3">Card Information</h6>
            <div className="p-3 border rounded mb-3 bg-light">
                <CardElement options={{
                    style: {
                        base: {
                            fontSize: '16px',
                            color: '#424770',
                            '::placeholder': {
                                color: '#aab7c4',
                            },
                        },
                        invalid: {
                            color: '#9e2146',
                        },
                    },
                }} />
            </div>
            <div className="text-end">
                <Button type="submit" disabled={!stripe || loading} className="px-4 text-white" style={{ backgroundColor: '#14ab71', border: 'none' }}>
                    {loading ? <Spinner animation="border" size="sm" /> : "Save Card"}
                </Button>
            </div>
        </form>
    );
};

// ─────────────────────────────────────────────────────────────────────────────
// Apple Pay Component
// ─────────────────────────────────────────────────────────────────────────────
const ExpressPayComponent = ({ plan, type }) => {
    const stripe = useStripe();
    const { data: session, update } = useSession();
    const router = useRouter();
    const [paymentRequest, setPaymentRequest] = useState(null);
    const [canMakePayment, setCanMakePayment] = useState(false);
    const isMTD = session?.user?.userRole === 'MTD' || session?.user?.role === 'MTD';

    useEffect(() => {
        if (stripe && plan) {
            const basePrice = plan?.price ? parseFloat(plan.price) : 0;
            const vatRate = plan?.vatPercentage !== undefined ? parseFloat(plan.vatPercentage) : 20;
            const vatAmount = basePrice * (vatRate / 100);
            const totalAmount = basePrice + vatAmount;

            const pr = stripe.paymentRequest({
                country: 'GB',
                currency: (plan.currency || 'GBP').toLowerCase(),
                total: {
                    label: plan.name,
                    amount: Math.round(totalAmount * 100),
                },
                requestPayerName: true,
                requestPayerEmail: true,
            });

            pr.canMakePayment().then((result) => {
                console.log(`Stripe PaymentRequest canMakePayment result for ${type}:`, result);
                if (result) {
                    setPaymentRequest(pr);
                    if (type === 'apple') {
                        setCanMakePayment(!!result.applePay);
                    } else if (type === 'google') {
                        setCanMakePayment(!!(result.googlePay || (!result.applePay && result)));
                    } else {
                        setCanMakePayment(true);
                    }
                } else {
                    setCanMakePayment(false);
                }
            }).catch((err) => {
                console.error("Stripe canMakePayment error:", err);
                setCanMakePayment(false);
            });
        }
    }, [stripe, plan, type]);

    useEffect(() => {
        if (!paymentRequest) return;

        // Ensure we only attach the listener once
        paymentRequest.off('paymentmethod');
        paymentRequest.on('paymentmethod', async (ev) => {
            try {
                const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
                const response = await axios.post(
                    `${apiUrl}client/subscription/create`,
                    {
                        planId: plan.id,
                        paymentMethodId: ev.paymentMethod.id,
                        priceId: plan.priceId || plan.stripePriceId || plan.stripe_price_id || plan.id,
                    },
                    { headers: { Authorization: `Bearer ${session.accessToken}` } }
                );

                if (response.data && response.data.requiresAction && response.data.paymentIntent) {
                    const { client_secret } = response.data.paymentIntent;
                    const result = await stripe.confirmCardPayment(client_secret);
                    if (result.error) {
                        ev.complete('fail');
                        toast.error(result.error.message || "Authentication failed");
                    } else {
                        await axios.post(
                            `${apiUrl}client/subscription/confirm`,
                            { stripeSubscriptionId: response.data.stripeSubscriptionId },
                            { headers: { Authorization: `Bearer ${session.accessToken}` } }
                        );
                        ev.complete('success');
                        toast.success("Subscription purchased successfully!");
                        await update({ isSubscriptionBuy: true });
                        router.push(isMTD ? '/mtd-dashboard?tab=subscriptions' : '/dashboard/my-subscriptions');
                    }
                } else {
                    ev.complete('success');
                    toast.success("Subscription purchased successfully!");
                    await update({ isSubscriptionBuy: true });
                    router.push(isMTD ? '/mtd-dashboard?tab=subscriptions' : '/dashboard/my-subscriptions');
                }
            } catch (err) {
                console.error('Express Pay purchase failed:', err);
                ev.complete('fail');
                toast.error(err?.response?.data?.message || 'Failed to complete checkout. Please try again.');
            }
        });
    }, [paymentRequest, plan, session, stripe, router, isMTD, update]);

    if (!canMakePayment) {
        if (type === 'apple') {
            return (
                <div className="text-center p-4 border rounded bg-light text-muted">
                    <FaApple size={40} className="mb-2" />
                    <h6 className="fw-bold">Apple Pay is not available</h6>
                    <p className="mb-0" style={{ fontSize: '0.85rem' }}>
                        Please use Safari on a compatible Apple device with an active card in your Wallet to use Apple Pay.
                    </p>
                </div>
            );
        }
        return (
            <div className="text-center p-4 border rounded bg-light text-muted">
                <FaGoogle size={32} className="mb-2 mt-1" />
                <h6 className="fw-bold">Google Pay is not available</h6>
                <p className="mb-0" style={{ fontSize: '0.85rem' }}>
                    Please ensure you are using a compatible browser (like Chrome) and have a valid card saved in your Google Pay account.
                </p>
            </div>
        );
    }

    return (
        <div className="express-pay-container mt-3">
            <h6 className="fw-bold mb-3 text-muted d-flex align-items-center" style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Express Checkout
            </h6>
            <PaymentRequestButtonElement options={{ paymentRequest }} />
        </div>
    );
};

// ─────────────────────────────────────────────────────────────────────────────
// Payment Method Tab Styles
// ─────────────────────────────────────────────────────────────────────────────
const tabStyles = {
    container: {
        display: 'flex',
        gap: '0',
        borderBottom: '2px solid #e9ecef',
        marginBottom: '24px',
        flexWrap: 'wrap',
    },
    tab: (isActive) => ({
        padding: '12px 14px',
        cursor: 'pointer',
        fontWeight: isActive ? '700' : '500',
        fontSize: '15px',
        color: isActive ? '#14ab71' : '#6c757d',
        borderBottom: isActive ? '3px solid #14ab71' : '3px solid transparent',
        background: 'none',
        border: 'none',
        borderTop: 'none',
        borderLeft: 'none',
        borderRight: 'none',
        transition: 'all 0.2s ease',
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        whiteSpace: 'nowrap',
        flexShrink: 0,
    }),
};

// ─────────────────────────────────────────────────────────────────────────────
// Main Checkout Page Component
// ─────────────────────────────────────────────────────────────────────────────
const PlanCheckoutPage = () => {
    const params = useParams();
    const router = useRouter();
    const { data: session, update } = useSession();
    const planId = params?.id;
    const isMTD = session?.user?.userRole === 'MTD' || session?.user?.role === 'MTD';

    const [plan, setPlan] = useState(null);
    const [loadingPlan, setLoadingPlan] = useState(true);

    const [cards, setCards] = useState([]);
    const [loadingCards, setLoadingCards] = useState(true);
    const [selectedCardId, setSelectedCardId] = useState(null);

    const [paying, setPaying] = useState(false);
    const [activePaymentMethod, setActivePaymentMethod] = useState('card'); // 'card' | 'klarna' | 'clearpay'

    // Klarna & Clearpay are only available for one-time and yearly subscriptions.
    // They are completely removed from all Monthly subscription checkout pages.
    const isYearlyPlan = plan?.interval === 'year' || plan?.interval === 'yearly';
    const isRecurringPlan = !isYearlyPlan;

    const [paymentSupport, setPaymentSupport] = useState({ applePay: false, googlePay: false });

    useEffect(() => {
        if (!plan) return;
        stripePromise.then(stripe => {
            if (!stripe) return;
            const basePrice = plan?.price ? parseFloat(plan.price) : 0;
            const vatRate = plan?.vatPercentage !== undefined ? parseFloat(plan.vatPercentage) : 20;
            const totalAmount = basePrice + (basePrice * (vatRate / 100));

            const pr = stripe.paymentRequest({
                country: 'GB',
                currency: (plan.currency || 'GBP').toLowerCase(),
                total: { label: plan.name, amount: Math.round(totalAmount * 100) },
            });

            pr.canMakePayment().then(result => {
                setPaymentSupport({
                    applePay: !!result?.applePay,
                    googlePay: !!(result?.googlePay || (result && !result.applePay))
                });
            }).catch(err => {
                console.error("Global canMakePayment error:", err);
            });
        });
    }, [plan]);

    useEffect(() => {
        if (!planId) return;

        const fetchPlanDetails = async () => {
            try {
                const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
                const response = await axios.get(`${apiUrl}subscription-plans/${planId}`);
                if (response.data && response.data.data) {
                    setPlan(response.data.data);
                } else {
                    toast.error("Plan not found");
                }
            } catch (err) {
                console.error("Error fetching plan:", err);
                toast.error("Unable to load plan details.");
            } finally {
                setLoadingPlan(false);
            }
        };

        fetchPlanDetails();
    }, [planId]);

    const fetchCards = async () => {
        if (!session?.accessToken) return;
        setLoadingCards(true);
        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
            const response = await axios.get(`${apiUrl}client/subscription/cards/list`, {
                headers: { Authorization: `Bearer ${session.accessToken}` }
            });
            const responseData = response.data?.data;
            const cardList = Array.isArray(responseData) ? responseData : (responseData?.cards || []);

            setCards(cardList);
            if (cardList.length > 0 && !selectedCardId) {
                setSelectedCardId(cardList[0].id);
            }
        } catch (err) {
            console.error("Error fetching cards:", err);
        } finally {
            setLoadingCards(false);
        }
    };

    useEffect(() => {
        if (session?.accessToken) {
            fetchCards();
        }
    }, [session?.accessToken]);

    const handleDeleteCard = async (cardId) => {
        if (!confirm("Are you sure you want to delete this card?")) return;

        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
            await axios.delete(`${apiUrl}client/subscription/cards/delete/${cardId}`, {
                headers: { Authorization: `Bearer ${session.accessToken}` }
            });
            toast.success("Card deleted");

            if (selectedCardId === cardId) {
                setSelectedCardId(null);
            }
            fetchCards();
        } catch (err) {
            console.error("Error deleting card:", err);
            toast.error("Failed to delete card");
        }
    };

    // ── Card Payment Handler ─────────────────────────────────────────────────
    const handleCardPayment = async () => {
        if (!selectedCardId) {
            toast.error("Please select a valid payment method");
            return;
        }

        setPaying(true);
        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
            const response = await axios.post(
                `${apiUrl}client/subscription/create`,
                {
                    planId: planId,
                    paymentMethodId: selectedCardId,
                    priceId: plan?.priceId || plan?.stripePriceId || plan?.stripe_price_id || plan?.id,
                },
                { headers: { Authorization: `Bearer ${session.accessToken}` } }
            );

            // If additional authentication is required (e.g., 3DS), handle it
            if (response.data && response.data.requiresAction && response.data.paymentIntent) {
                const { client_secret } = response.data.paymentIntent;
                const stripe = await stripePromise;
                const result = await stripe.confirmCardPayment(client_secret);
                if (result.error) {
                    toast.error(result.error.message || "Authentication failed");
                } else {
                    // Authentication succeeded, confirm the subscription on backend
                    await axios.post(
                        `${apiUrl}client/subscription/confirm`,
                        { stripeSubscriptionId: response.data.stripeSubscriptionId },
                        { headers: { Authorization: `Bearer ${session.accessToken}` } }
                    );
                    toast.success("Subscription purchased successfully!");
                    await update({ isSubscriptionBuy: true });
                    router.push(isMTD ? '/mtd-dashboard?tab=subscriptions' : '/dashboard/my-subscriptions');
                }
            } else {
                toast.success("Subscription purchased successfully!");
                await update({ isSubscriptionBuy: true });
                router.push(isMTD ? '/mtd-dashboard?tab=subscriptions' : '/dashboard/my-subscriptions');
            }
        } catch (err) {
            console.error('Purchase failed:', err);
            toast.error(err?.response?.data?.message || 'Failed to complete purchase. Please try again.');
        } finally {
            setPaying(false);
        }
    };

    // ── Klarna / Clearpay Payment Handler ────────────────────────────────────
    const handleAlternativePayment = async (paymentMethod) => {
        setPaying(true);
        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001/api/';
            const response = await axios.post(
                `${apiUrl}client/subscription/checkout-session`,
                {
                    planId: planId,
                    paymentMethod: paymentMethod,
                },
                { headers: { Authorization: `Bearer ${session.accessToken}` } }
            );

            const checkoutUrl = response.data?.data?.checkoutUrl;
            if (checkoutUrl) {
                // Open Stripe Checkout
                window.location.href = checkoutUrl;
            } else {
                toast.error("Failed to create checkout session. Please try again.");
            }
        } catch (err) {
            console.error(`${paymentMethod} checkout failed:`, err);
            toast.error(err?.response?.data?.message || `Failed to initiate ${paymentMethod === 'klarna' ? 'Klarna' : 'Clearpay'} payment.`);
        } finally {
            setPaying(false);
        }
    };

    // ── Unified Pay Handler ──────────────────────────────────────────────────
    const handlePayment = async () => {
        if (activePaymentMethod === 'card') {
            await handleCardPayment();
        } else if (activePaymentMethod === 'klarna') {
            await handleAlternativePayment('klarna');
        } else if (activePaymentMethod === 'clearpay') {
            await handleAlternativePayment('afterpay_clearpay');
        }
    };

    if (loadingPlan) {
        return (
            <div className="d-flex justify-content-center align-items-center" style={{ height: "100vh" }}>
                <Spinner animation="border" variant="primary" />
            </div>
        );
    }

    if (!plan) {
        return (
            <div className="text-center py-5">
                <h2>Plan not found</h2>
            </div>
        );
    }

    // Calculate VAT and Total
    const basePrice = plan?.price ? parseFloat(plan.price) : 0;
    const vatRate = plan?.vatPercentage !== undefined ? parseFloat(plan.vatPercentage) : 20;
    const vatAmount = basePrice * (vatRate / 100);
    const totalAmount = basePrice + vatAmount;

    // Calculate installment amount for Clearpay (4 payments)
    const installmentAmount = totalAmount ? (totalAmount / 4).toFixed(2) : '0.00';

    return (
        <div className="checkout-wrapper" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '40px 0' }}>
            <Container>
                <div className="mb-4">
                    <h5><span className="text-muted" style={{ cursor: 'pointer' }} onClick={() => router.push('/planlist')}>Home</span> / Checkout</h5>
                </div>

                <Row className="g-4">
                    {/* Left Column: Plan Details + Payment Methods */}
                    <Col lg={6}>
                        {/* Plan Details Card */}
                        <Card className="border-0 shadow-sm mb-4" style={{ borderRadius: '12px' }}>
                            <Card.Body className="p-4">
                                <h4 className="mb-4 fw-bold">Price Breakdown ({plan.name})</h4>
                                <div className="d-flex justify-content-between align-items-center mb-2">
                                    <h6 className="fs-6 mb-0 fw-medium">Package Price</h6>
                                    <h6 className="text-muted fw-normal mb-0">
                                        {getCurrencySymbol(plan.currency)}{basePrice.toFixed(2)}
                                    </h6>
                                </div>
                                <div className="d-flex justify-content-between align-items-center mb-2">
                                    <h6 className="fs-6 mb-0 fw-medium">VAT {vatRate}%</h6>
                                    <h6 className="text-muted fw-normal mb-0">
                                        {getCurrencySymbol(plan.currency)}{vatAmount.toFixed(2)}
                                    </h6>
                                </div>
                                <hr className="my-3" />
                                <div className="d-flex justify-content-between align-items-center mb-3">
                                    <h5 className="fs-5 mb-0 fw-bold">Total</h5>
                                    <h5 className="fw-bold mb-0 text-success">
                                        {getCurrencySymbol(plan.currency)}{totalAmount.toFixed(2)} / {plan.interval === 'year' ? 'year' : 'month'}
                                    </h5>
                                </div>
                                <hr className="mb-4" />
                                <h6 className="fw-bold mb-3">Description</h6>
                                {plan.description && <p className="text-muted mb-3">{plan.description}</p>}
                                <ul className="list-unstyled">
                                    {Array.isArray(plan.features) && plan.features.map((feature, idx) => (
                                        <li key={idx} className="mb-2 d-flex align-items-start">
                                            <MdCheckCircle className="text-success me-2 mt-1" style={{ fontSize: '1.2rem' }} />
                                            <span>{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                            </Card.Body>
                        </Card>

                        {/* Your Payment Methods (Cards) — only show when card tab is active */}
                        {activePaymentMethod === 'card' && (
                            <Card className="border-0 shadow-sm" style={{ borderRadius: '12px' }}>
                                <Card.Body className="p-4">
                                    <h4 className="mb-4 fw-bold">Your Payment Methods</h4>
                                    {loadingCards ? (
                                        <div className="text-center py-3"><Spinner animation="border" size="sm" /></div>
                                    ) : cards.length > 0 ? (
                                        <div>
                                            {cards.map(card => (
                                                <div
                                                    key={card.id}
                                                    className={`p-3 border rounded mb-3 position-relative ${selectedCardId === card.id ? 'border-success' : 'border-light-subtle'}`}
                                                    style={{ 
                                                        cursor: 'pointer', 
                                                        borderColor: selectedCardId === card.id ? '#14ab71' : '#dee2e6', 
                                                        borderWidth: '2px', 
                                                        borderStyle: 'solid',
                                                        backgroundColor: selectedCardId === card.id ? '#f0fff4' : '#fff',
                                                        transition: 'all 0.2s ease-in-out',
                                                        boxShadow: selectedCardId === card.id ? '0 4px 6px rgba(20, 171, 113, 0.1)' : 'none'
                                                    }}
                                                    onClick={() => setSelectedCardId(card.id)}
                                                >
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <div className="d-flex align-items-center">
                                                            <div className="me-3 p-2 bg-white rounded shadow-sm border d-flex align-items-center justify-content-center" style={{ width: '50px', height: '40px' }}>
                                                                {getCardIcon(card.brand)}
                                                            </div>
                                                            <div>
                                                                <h6 className="mb-0 fw-bold">•••• •••• •••• {(card.last4 || '****').toString().slice(-4)}</h6>
                                                                <p className="mb-0 text-muted small mt-1">
                                                                    Exp: <span className="fw-medium">{card.exp_month || '*'}/{card.exp_year || '****'}</span>
                                                                    {card.brand && <span className="ms-2 text-capitalize badge bg-light text-dark border">{card.brand}</span>}
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex align-items-center gap-2">
                                                            {selectedCardId === card.id && (
                                                                <MdCheckCircle size={24} className="text-success" />
                                                            )}
                                                            <Button
                                                                variant="link"
                                                                className="text-danger p-0 ms-2"
                                                                style={{ textDecoration: 'none' }}
                                                                onClick={(e) => { e.stopPropagation(); handleDeleteCard(card.id); }}
                                                                title="Delete Card"
                                                            >
                                                                <FaTrash size={16} />
                                                            </Button>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <p className="text-muted">No saved cards found. Please add a card to proceed.</p>
                                    )}
                                </Card.Body>
                            </Card>
                        )}
                    </Col>

                    {/* Right Column: Payment Method Tabs + Pay Button */}
                    <Col lg={6}>
                        <Card className="border-0 shadow-sm mb-4" style={{ borderRadius: '12px' }}>
                            <Card.Body className="p-4">
                                {/* ── Payment Method Tabs ─────────────────────────── */}
                                <div style={tabStyles.container} className='pay-btn'>
                                    <button
                                        style={tabStyles.tab(activePaymentMethod === 'card')}
                                        onClick={() => setActivePaymentMethod('card')}
                                        id="tab-card-payment"
                                    >
                                        <FaCreditCard size={18} />
                                        Card
                                    </button>
                                    {paymentSupport.applePay && (
                                        <button
                                            style={tabStyles.tab(activePaymentMethod === 'apple_pay')}
                                            onClick={() => setActivePaymentMethod('apple_pay')}
                                            id="tab-applepay-payment"
                                        >
                                            <FaApple size={18} />
                                            Apple Pay
                                        </button>
                                    )}
                                    {paymentSupport.googlePay && (
                                        <button
                                            style={tabStyles.tab(activePaymentMethod === 'google_pay')}
                                            onClick={() => setActivePaymentMethod('google_pay')}
                                            id="tab-googlepay-payment"
                                        >
                                            <FaGoogle size={16} />
                                            Google Pay
                                        </button>
                                    )}
                                    {/* Klarna & Clearpay: Only for Self Assessment (one-time) plans */}
                                    {!isRecurringPlan && (
                                        <button
                                            style={tabStyles.tab(activePaymentMethod === 'klarna')}
                                            onClick={() => setActivePaymentMethod('klarna')}
                                            id="tab-klarna-payment"
                                        >
                                            <span style={{ 
                                                backgroundColor: '#FFB3C7', 
                                                color: '#17120F', 
                                                fontWeight: 800, 
                                                fontSize: '11px', 
                                                padding: '2px 6px', 
                                                borderRadius: '4px',
                                                letterSpacing: '0.3px',
                                            }}>K</span>
                                            Klarna
                                        </button>
                                    )}
                                    {!isRecurringPlan && (
                                        <button
                                            style={tabStyles.tab(activePaymentMethod === 'clearpay')}
                                            onClick={() => setActivePaymentMethod('clearpay')}
                                            id="tab-clearpay-payment"
                                        >
                                            <span style={{ 
                                                backgroundColor: '#B2FCE4', 
                                                color: '#000', 
                                                fontWeight: 800, 
                                                fontSize: '11px', 
                                                padding: '2px 6px', 
                                                borderRadius: '4px',
                                                letterSpacing: '0.3px',
                                            }}>C</span>
                                            Clearpay
                                        </button>
                                    )}
                                </div>

                                {/* ── Card Payment Tab Content ────────────────────── */}
                                {activePaymentMethod === 'card' && (
                                    <>
                                        <div className="d-flex flex-wrap flex-lg-nowrap gap-2 mb-4">
                                            <span className="text-muted d-flex align-items-center" style={{ fontSize: '0.9rem' }}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#14ab71" viewBox="0 0 16 16" className="me-2">
                                                    <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2m3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2"/>
                                                </svg>
                                                Secure encrypted transaction
                                            </span>
                                        </div>

                                        <div className="mb-4 p-3 bg-light rounded" style={{ border: '1px solid #e9ecef' }}>
                                            <h6 className="fw-bold mb-3 text-muted d-flex align-items-center" style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                                                <img src="https://flagcdn.com/w20/gb.png" alt="UK" className="me-2" style={{ width: '18px', height: '12px' }} />
                                                Commonly Accepted Cards in the UK
                                            </h6>
                                            <ul className="list-unstyled mb-0 d-flex flex-wrap" style={{ fontSize: '0.9rem', columnGap: '20px', rowGap: '12px' }}>
                                                <li className="d-flex align-items-center fw-bold"><FaCcVisa size={22} className="text-primary me-2" /> Visa</li>
                                                <li className="d-flex align-items-center fw-bold"><FaCcMastercard size={22} className="text-danger me-2" /> Mastercard</li>
                                                <li className="d-flex align-items-center"><FaCcAmex size={22} className="text-info me-2" /> American Express</li>
                                                <li className="d-flex align-items-center"><FaCreditCard size={18} className="text-secondary me-2" /> Maestro</li>
                                                <li className="d-flex align-items-center"><FaCcDiscover size={22} className="text-warning me-2" /> Discover & Diners</li>
                                                <li className="d-flex align-items-center"><FaCcJcb size={22} className="text-success me-2" /> JCB</li>
                                            </ul>
                                            <p className="mb-0 mt-3 text-muted" style={{ fontSize: '0.75rem' }}>*All transactions are processed securely via Stripe UK.</p>
                                        </div>

                                        <Elements stripe={stripePromise}>
                                            <AddCardForm onCardAdded={fetchCards} />
                                        </Elements>
                                    </>
                                )}

                                {/* ── Apple Pay Tab Content ────────────────────────── */}
                                {activePaymentMethod === 'apple_pay' && (
                                    <Elements stripe={stripePromise}>
                                        <ExpressPayComponent plan={plan} type="apple" />
                                    </Elements>
                                )}

                                {activePaymentMethod === 'google_pay' && (
                                    <Elements stripe={stripePromise}>
                                        <ExpressPayComponent plan={plan} type="google" />
                                    </Elements>
                                )}

                                {/* ── Klarna Tab Content ──────────────────────────── */}
                                {activePaymentMethod === 'klarna' && (
                                    <div className="klarna-content p-4 text-center border rounded bg-white shadow-sm mb-4">
                                        <div className="mb-3">
                                            <span style={{ fontSize: '2rem', fontWeight: 'bold' }}>Klarna.</span>
                                        </div>
                                        <h5 className="mb-3 fw-bold">Pay later with Klarna.</h5>
                                        <p className="text-muted mb-4" style={{ fontSize: '0.95rem' }}>
                                            Split your purchase into manageable payments or pay later in 30 days. No upfront payments, no interest, and no fees when you pay on time.
                                        </p>
                                        <div className="p-3 bg-light rounded text-start mx-auto" style={{ maxWidth: '400px' }}>
                                            <p className="mb-1 fw-bold text-dark" style={{ fontSize: '0.85rem' }}>✔ Quick and easy checkout</p>
                                            <p className="mb-1 fw-bold text-dark" style={{ fontSize: '0.85rem' }}>✔ Buyer protection included</p>
                                            <p className="mb-0 fw-bold text-dark" style={{ fontSize: '0.85rem' }}>✔ Safe and secure payments</p>
                                        </div>
                                        <div className="p-3 bg-light rounded text-start mx-auto mt-4" style={{ maxWidth: '400px' }}>
                                            <div className="d-flex justify-content-between align-items-center">
                                                <span className="text-muted" style={{ fontSize: '0.85rem' }}>Total amount (Inc. VAT)</span>
                                                <span className="fw-bold text-dark">{getCurrencySymbol(plan.currency)}{totalAmount.toFixed(2)}</span>
                                            </div>
                                        </div>

                                        <p className="text-muted mt-4 mb-0" style={{ fontSize: '0.85rem' }}>
                                            You will be redirected to Stripe Checkout to securely complete your Klarna payment.
                                        </p>
                                    </div>
                                )}

                                {/* ── Clearpay Tab Content ────────────────────────── */}
                                {activePaymentMethod === 'clearpay' && (
                                    <div className="clearpay-content p-4 text-center border rounded bg-white shadow-sm mb-4">
                                        <div className="mb-3">
                                            <span style={{ fontSize: '2rem', fontWeight: 'bold', fontStyle: 'italic' }}>Clearpay</span>
                                        </div>
                                        <h5 className="mb-3 fw-bold">Pay in 4 interest-free payments</h5>
                                        <p className="text-muted mb-4" style={{ fontSize: '0.95rem' }}>
                                            Shop now and pay for your purchase in 4 equal installments, due every 2 weeks. Always zero interest.
                                        </p>
                                        <div className="p-3 bg-light rounded text-start mx-auto" style={{ maxWidth: '400px' }}>
                                            <div className="d-flex justify-content-between mb-2 pb-2 border-bottom">
                                                <span className="text-muted" style={{ fontSize: '0.85rem' }}>Total amount (Inc. VAT)</span>
                                                <span className="fw-bold">{getCurrencySymbol(plan.currency)}{totalAmount.toFixed(2)}</span>
                                            </div>
                                            <div className="d-flex justify-content-between">
                                                <span className="text-muted" style={{ fontSize: '0.85rem' }}>4 payments of</span>
                                                <span className="fw-bold text-success">{getCurrencySymbol(plan.currency)}{totalAmount ? (totalAmount / 4).toFixed(2) : '0.00'}</span>
                                            </div>
                                        </div>
                                        <p className="text-muted mt-4 mb-0" style={{ fontSize: '0.85rem' }}>
                                            You will be redirected to Stripe Checkout to securely complete your Clearpay payment.
                                        </p>
                                    </div>
                                )}

                            </Card.Body>
                        </Card>

                        {/* Pay Action */}
                        <div className="d-flex justify-content-end mt-4">
                            {activePaymentMethod === 'card' ? (
                                <Button
                                    id="btn-pay-now-card"
                                    className="px-5 py-2 fw-bold text-white shadow-sm"
                                    style={{ fontSize: '1.2rem', borderRadius: '8px', backgroundColor: '#14ab71', border: 'none' }}
                                    onClick={handlePayment}
                                    disabled={paying || cards.length === 0 || !selectedCardId}
                                >
                                    {paying ? <Spinner animation="border" size="sm" className="me-2" /> : null}
                                    Pay {getCurrencySymbol(plan.currency)}{totalAmount.toFixed(2)} (Inc. VAT)
                                </Button>
                            ) : activePaymentMethod === 'apple_pay' || activePaymentMethod === 'google_pay' ? (
                                null /* Wallet buttons handle their own submission */
                            ) : activePaymentMethod === 'klarna' ? (
                                <Button
                                    id="btn-pay-with-klarna"
                                    className="px-5 py-2 fw-bold text-white shadow-sm"
                                    style={{
                                        fontSize: '1.1rem',
                                        borderRadius: '8px',
                                        backgroundColor: '#14ab71',
                                        border: 'none',
                                        transition: 'all 0.2s ease',
                                    }}
                                    onClick={handlePayment}
                                    disabled={paying}
                                >
                                    {paying ? <Spinner animation="border" size="sm" className="me-2" /> : null}
                                    Continue to Checkout ({getCurrencySymbol(plan.currency)}{totalAmount.toFixed(2)} Inc. VAT)
                                </Button>
                            ) : (
                                <Button
                                    id="btn-pay-with-clearpay"
                                    className="px-5 py-2 fw-bold text-white shadow-sm"
                                    style={{
                                        fontSize: '1.1rem',
                                        borderRadius: '8px',
                                        backgroundColor: '#14ab71',
                                        border: 'none',
                                        transition: 'all 0.2s ease',
                                    }}
                                    onClick={handlePayment}
                                    disabled={paying}
                                >
                                    {paying ? <Spinner animation="border" size="sm" className="me-2" /> : null}
                                    Continue to Checkout ({getCurrencySymbol(plan.currency)}{totalAmount.toFixed(2)} Inc. VAT)
                                </Button>
                            )}
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default PlanCheckoutPage;
