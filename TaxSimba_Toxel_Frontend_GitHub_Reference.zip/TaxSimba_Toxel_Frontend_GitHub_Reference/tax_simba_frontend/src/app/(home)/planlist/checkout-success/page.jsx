"use client";
import { useSession } from 'next-auth/react';
import { useEffect, useState, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Spinner, Container, Card, Button } from "react-bootstrap";
import axios from "axios";
import toast from "react-hot-toast";

/**
 * Checkout Success Page
 * URL: /planlist/checkout-success?session_id={CHECKOUT_SESSION_ID}
 * This page calls the backend endpoint to finalize the purchase
 * and then displays a success message. It redirects to the dashboard
 * after a short delay.
 */
const CheckoutSuccess = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const sessionId = searchParams?.get("session_id");
   console.log("sessionId ", sessionId)

  const { data: session, status, update } = useSession();
  const [loading, setLoading] = useState(true);
  const [purchaseInfo, setPurchaseInfo] = useState(null);
  const hasFinalized = useRef(false);

  useEffect(() => {
    if (status === "loading") return; // Wait for session to load
    if (hasFinalized.current) return; // Prevent multiple calls

    const finalize = async () => {
      hasFinalized.current = true;
      if (!sessionId) {
        toast.error("Missing session_id in URL.");
        router.push("/planlist");
        return;
      }

      // If user is unauthenticated, redirect or show error
      if (status === "unauthenticated" || !session?.accessToken) {
        toast.error("You must be logged in to complete this purchase.");
        router.push("/login");
        return;
      }

      try {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL;
        const response = await axios.post(
          `${apiUrl}client/subscription/checkout-success`,
          { sessionId },
          { headers: { Authorization: `Bearer ${session.accessToken}` } }
        );
        setPurchaseInfo(response.data?.data || {});
        
        // Update the session token to indicate the user has a subscription
        await update({ isSubscriptionBuy: true });
        
        toast.success("Your purchase was successful!");
      } catch (err) {
        console.error(err);
        toast.error(err?.response?.data?.message || "Failed to finalize purchase.");
        router.push("/planlist");
      } finally {
        setLoading(false);
      }
    };
    finalize();
  }, [sessionId, status, router]);

  // Auto‑redirect after 5 seconds
  useEffect(() => {
    if (!loading && purchaseInfo) {
      const timer = setTimeout(() => router.push("/dashboard/my-subscriptions"), 5000);
      return () => clearTimeout(timer);
    }
  }, [loading, purchaseInfo, router]);

  return (
    <Container className="d-flex align-items-center justify-content-center" style={{ minHeight: "80vh" }}>
      <Card className="shadow-sm" style={{ borderRadius: "12px", maxWidth: "500px", width: "100%" }}>
        <Card.Body className="p-4 text-center">
          {loading ? (
            <>
              <Spinner animation="border" className="mb-3" />
              <h5 className="mb-0">Finalising your purchase…</h5>
            </>
          ) : (
            <>
              <h4 className="mb-3 text-success">✅ Purchase Completed</h4>
              {purchaseInfo?.plan && (
                <p>
                  You have successfully subscribed to <strong>{purchaseInfo.plan.name}</strong>.
                </p>
              )}
              <p className="text-muted mb-4">You will be redirected to the next steps shortly.</p>
              <Button variant="primary" onClick={() => router.push("/dashboard/my-subscriptions")}>Proceed to Next Steps</Button>
            </>
          )}
        </Card.Body>
      </Card>
    </Container>
  );
};

export default CheckoutSuccess;
