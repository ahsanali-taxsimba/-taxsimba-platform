import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import axios from "axios";
import { cookies } from "next/headers";

export const authOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { name: "email", type: "text" },
        password: { name: "Password", type: "password" },
        code: { name: "code", type: "number" }
      },
      async authorize(credentials) {
        try {
          let res;
          if (credentials.code !== undefined && credentials.code !== 'null' && credentials.code !== "") {
            res = await axios.post(`${process.env.API_URL}/auth/login-with-code`, {
              email: credentials.email,
              action: "verify",
              code: credentials.code,
            });
          } else {
            res = await axios.post(`${process.env.API_URL}/auth/login`, {
              email: credentials.email,
              password: credentials.password,
            });
          }

          const user = res.data;

          if (res.status === 200 && user.data.accessToken) {
            return { ...user.data.user, accessToken: user.data.accessToken };
          }

          return null;
        } catch (error) {
          console.error("Authorize error:", error);
          if (axios.isAxiosError(error)) {
            const message = error.response?.data?.message || "Login failed. Please try again.";
            throw new Error(message);
          }
          throw new Error("Something went wrong during login.");
        }
      },
    }),
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    })
  ],

  callbacks: {
    async signIn({ user, account, profile }) {
      // Handle Google sign-in by calling your backend
      if (account?.provider === "google") {
        try {
          const cookieStore = await cookies();
          const userRole = cookieStore.get("register-role")?.value || "TAXSIMBA";

          const res = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}auth/google`, {
            credential: account.id_token,
            access_token: account.access_token,
            userRole: userRole,
          });

          // Clear register-role cookie
          cookieStore.set("register-role", "", { maxAge: 0, path: "/" });

          if (res.status === 200 && res.data.data) {
            user.backendData = res.data.data;
            return true;
          }
          return false;
        } catch (error) {
          console.error("Google sign-in error:", error);
          return false;
        }
      }
      return true;
    },

    async jwt({ token, user, account, trigger, session }) {
      // Allow dynamic updates to token parameters after login
      if (trigger === 'update') {
        if (session?.isSubscriptionBuy !== undefined && token.user) {
          token.user.isSubscriptionBuy = session.isSubscriptionBuy;
        }
        if (session?.isEngagementLetterAccepted !== undefined && token.user) {
          token.user.isEngagementLetterAccepted = session.isEngagementLetterAccepted;
        }
        if (session?.isTaxInfoSubmitted !== undefined && token.user) {
          token.user.isTaxInfoSubmitted = session.isTaxInfoSubmitted;
        }
      }

      if (user && user.accessToken) {
        token.accessToken = user.accessToken;
        token.user = user;
      }

      // Handle Google login - get data from backend
      if (user && user.backendData) {
        token.accessToken = user.backendData.accessToken;
        token.refreshToken = user.backendData.refreshToken;
        token.user = user.backendData.user;
      }
      return token;
    },

    async session({ session, token }) {
      session.accessToken = token.accessToken;
      session.refreshToken = token.refreshToken;
      session.user = token.user;
      return session;
    },
  },

  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },

  // Mirror exactly what the working admin uses:
  // - httpOnly: true on ALL cookies (including csrf) — standard NextAuth behaviour
  // - secure: tied to NODE_ENV — not hardcoded true
  // - no basePath override — the file path /frontend-api/auth/[...nextauth] handles routing
  cookies: {
    sessionToken: {
      name: "next-auth.session-token-frontend",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
      },
    },
    callbackUrl: {
      name: "next-auth.callback-url-frontend",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
      },
    },
    csrfToken: {
      name: "next-auth.csrf-token-frontend",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
      },
    },
    pkceCodeVerifier: {
      name: "next-auth.pkce.code_verifier-frontend",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
        maxAge: 900,
      },
    },
    state: {
      name: "next-auth.state-frontend",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
        maxAge: 900,
      },
    },
    nonce: {
      name: "next-auth.nonce-frontend",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
      },
    },
  },

  pages: {
    signIn: "/login",
  },

  // Use NEXTAUTH_SECRET (same as admin) — not a custom _FRONTEND variant
  secret: process.env.NEXTAUTH_SECRET,

  // Enable debug logging in development — helps diagnose auth issues
  debug: process.env.NODE_ENV === "development",
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };